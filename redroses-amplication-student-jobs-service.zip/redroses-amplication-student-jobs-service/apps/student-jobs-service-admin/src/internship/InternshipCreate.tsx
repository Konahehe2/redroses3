import * as React from "react";

import {
  Create,
  SimpleForm,
  CreateProps,
  TextInput,
  ReferenceInput,
  SelectInput,
  NumberInput,
} from "react-admin";

import { EmployerTitle } from "../employer/EmployerTitle";

export const InternshipCreate = (props: CreateProps): React.ReactElement => {
  return (
    <Create {...props}>
      <SimpleForm>
        <TextInput label="description" multiline source="description" />
        <TextInput label="duration" source="duration" />
        <ReferenceInput
          source="employer.id"
          reference="Employer"
          label="employer"
        >
          <SelectInput optionText={EmployerTitle} />
        </ReferenceInput>
        <TextInput label="location" source="location" />
        <NumberInput label="stipend" source="stipend" />
        <TextInput label="title" source="title" />
      </SimpleForm>
    </Create>
  );
};
