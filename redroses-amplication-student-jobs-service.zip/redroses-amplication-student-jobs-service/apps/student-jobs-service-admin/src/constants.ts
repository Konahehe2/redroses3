export const CREDENTIALS_LOCAL_STORAGE_ITEM = "credentials";
export const USER_DATA_LOCAL_STORAGE_ITEM = "userData";
