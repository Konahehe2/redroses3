import { InputJsonValue } from "../types";
export class JsonFilter {
  equals?: InputJsonValue;
  not?: InputJsonValue;
}
