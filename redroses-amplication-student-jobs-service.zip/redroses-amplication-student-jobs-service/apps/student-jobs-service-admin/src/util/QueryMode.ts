export enum QueryMode {
  Default = "default",
  Insensitive = "insensitive",
}
