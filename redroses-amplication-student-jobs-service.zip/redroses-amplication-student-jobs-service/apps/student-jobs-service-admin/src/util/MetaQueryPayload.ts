export class MetaQueryPayload {
  count!: number;
}
