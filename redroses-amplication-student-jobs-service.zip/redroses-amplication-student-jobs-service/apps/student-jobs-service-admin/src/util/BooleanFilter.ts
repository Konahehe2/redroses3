export class BooleanFilter {
  equals?: boolean;
  not?: boolean;
}
