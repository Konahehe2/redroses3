import { Internship } from "../internship/Internship";
import { Job } from "../job/Job";

export type Employer = {
  companyName: string | null;
  contactEmail: string | null;
  createdAt: Date;
  description: string | null;
  id: string;
  internships?: Array<Internship>;
  jobs?: Array<Job>;
  updatedAt: Date;
  website: string | null;
};
