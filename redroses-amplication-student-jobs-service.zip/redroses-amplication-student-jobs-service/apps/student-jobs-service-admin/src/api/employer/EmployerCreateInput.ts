import { InternshipCreateNestedManyWithoutEmployersInput } from "./InternshipCreateNestedManyWithoutEmployersInput";
import { JobCreateNestedManyWithoutEmployersInput } from "./JobCreateNestedManyWithoutEmployersInput";

export type EmployerCreateInput = {
  companyName?: string | null;
  contactEmail?: string | null;
  description?: string | null;
  internships?: InternshipCreateNestedManyWithoutEmployersInput;
  jobs?: JobCreateNestedManyWithoutEmployersInput;
  website?: string | null;
};
