import { EmployerWhereUniqueInput } from "./EmployerWhereUniqueInput";

export type DeleteEmployerArgs = {
  where: EmployerWhereUniqueInput;
};
