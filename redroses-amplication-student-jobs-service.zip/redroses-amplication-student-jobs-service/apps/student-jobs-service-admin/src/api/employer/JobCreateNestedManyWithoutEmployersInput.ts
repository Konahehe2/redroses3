import { JobWhereUniqueInput } from "../job/JobWhereUniqueInput";

export type JobCreateNestedManyWithoutEmployersInput = {
  connect?: Array<JobWhereUniqueInput>;
};
