import { InternshipWhereUniqueInput } from "../internship/InternshipWhereUniqueInput";

export type InternshipUpdateManyWithoutEmployersInput = {
  connect?: Array<InternshipWhereUniqueInput>;
  disconnect?: Array<InternshipWhereUniqueInput>;
  set?: Array<InternshipWhereUniqueInput>;
};
