import { EmployerCreateInput } from "./EmployerCreateInput";

export type CreateEmployerArgs = {
  data: EmployerCreateInput;
};
