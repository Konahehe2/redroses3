import { InternshipWhereUniqueInput } from "../internship/InternshipWhereUniqueInput";

export type InternshipCreateNestedManyWithoutEmployersInput = {
  connect?: Array<InternshipWhereUniqueInput>;
};
