import { EmployerWhereUniqueInput } from "./EmployerWhereUniqueInput";

export type EmployerFindUniqueArgs = {
  where: EmployerWhereUniqueInput;
};
