export type EmployerWhereUniqueInput = {
  id: string;
};
