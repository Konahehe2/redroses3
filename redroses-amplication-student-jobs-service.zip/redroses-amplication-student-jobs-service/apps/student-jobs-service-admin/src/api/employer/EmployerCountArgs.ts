import { EmployerWhereInput } from "./EmployerWhereInput";

export type EmployerCountArgs = {
  where?: EmployerWhereInput;
};
