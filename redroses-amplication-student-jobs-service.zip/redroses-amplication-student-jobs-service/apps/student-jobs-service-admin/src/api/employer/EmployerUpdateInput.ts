import { InternshipUpdateManyWithoutEmployersInput } from "./InternshipUpdateManyWithoutEmployersInput";
import { JobUpdateManyWithoutEmployersInput } from "./JobUpdateManyWithoutEmployersInput";

export type EmployerUpdateInput = {
  companyName?: string | null;
  contactEmail?: string | null;
  description?: string | null;
  internships?: InternshipUpdateManyWithoutEmployersInput;
  jobs?: JobUpdateManyWithoutEmployersInput;
  website?: string | null;
};
