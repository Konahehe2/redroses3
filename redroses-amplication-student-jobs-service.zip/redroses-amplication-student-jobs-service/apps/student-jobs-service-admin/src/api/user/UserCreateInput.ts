import { ApplicationCreateNestedManyWithoutUsersInput } from "./ApplicationCreateNestedManyWithoutUsersInput";
import { InputJsonValue } from "../../types";

export type UserCreateInput = {
  applications?: ApplicationCreateNestedManyWithoutUsersInput;
  education?: string | null;
  email?: string | null;
  firstName?: string | null;
  lastName?: string | null;
  password: string;
  photo?: InputJsonValue;
  roles: InputJsonValue;
  userType?: "Option1" | null;
  username?: string | null;
};
