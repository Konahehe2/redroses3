import { Application } from "../application/Application";
import { JsonValue } from "type-fest";

export type User = {
  applications?: Array<Application>;
  createdAt: Date;
  education: string | null;
  email: string | null;
  firstName: string | null;
  id: string;
  lastName: string | null;
  photo: JsonValue;
  roles: JsonValue;
  updatedAt: Date;
  userType?: "Option1" | null;
  username: string | null;
};
