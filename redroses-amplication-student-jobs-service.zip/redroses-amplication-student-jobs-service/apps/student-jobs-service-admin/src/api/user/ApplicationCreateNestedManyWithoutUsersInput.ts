import { ApplicationWhereUniqueInput } from "../application/ApplicationWhereUniqueInput";

export type ApplicationCreateNestedManyWithoutUsersInput = {
  connect?: Array<ApplicationWhereUniqueInput>;
};
