import { UserWhereUniqueInput } from "./UserWhereUniqueInput";

export type DeleteUserArgs = {
  where: UserWhereUniqueInput;
};
