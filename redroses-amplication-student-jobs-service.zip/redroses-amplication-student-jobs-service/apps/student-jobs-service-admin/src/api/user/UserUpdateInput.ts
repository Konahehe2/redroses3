import { ApplicationUpdateManyWithoutUsersInput } from "./ApplicationUpdateManyWithoutUsersInput";
import { InputJsonValue } from "../../types";

export type UserUpdateInput = {
  applications?: ApplicationUpdateManyWithoutUsersInput;
  education?: string | null;
  email?: string | null;
  firstName?: string | null;
  lastName?: string | null;
  password?: string;
  photo?: InputJsonValue;
  roles?: InputJsonValue;
  userType?: "Option1" | null;
  username?: string | null;
};
