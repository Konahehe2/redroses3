import { StringFilter } from "../../util/StringFilter";
import { JobWhereUniqueInput } from "../job/JobWhereUniqueInput";
import { DateTimeNullableFilter } from "../../util/DateTimeNullableFilter";
import { UserWhereUniqueInput } from "../user/UserWhereUniqueInput";

export type ApplicationWhereInput = {
  id?: StringFilter;
  job?: JobWhereUniqueInput;
  status?: "Option1";
  submissionDate?: DateTimeNullableFilter;
  user?: UserWhereUniqueInput;
};
