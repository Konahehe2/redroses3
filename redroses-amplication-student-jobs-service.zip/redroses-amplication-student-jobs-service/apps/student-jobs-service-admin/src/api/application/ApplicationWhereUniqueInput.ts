export type ApplicationWhereUniqueInput = {
  id: string;
};
