import { ApplicationWhereInput } from "./ApplicationWhereInput";

export type ApplicationCountArgs = {
  where?: ApplicationWhereInput;
};
