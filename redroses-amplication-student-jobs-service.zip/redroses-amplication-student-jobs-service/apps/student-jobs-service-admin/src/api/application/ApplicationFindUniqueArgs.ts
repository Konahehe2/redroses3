import { ApplicationWhereUniqueInput } from "./ApplicationWhereUniqueInput";

export type ApplicationFindUniqueArgs = {
  where: ApplicationWhereUniqueInput;
};
