export enum EnumApplicationStatus {
  Option_1 = "Option1",
}
