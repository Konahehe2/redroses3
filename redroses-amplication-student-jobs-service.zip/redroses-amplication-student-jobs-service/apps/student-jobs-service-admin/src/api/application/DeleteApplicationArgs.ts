import { ApplicationWhereUniqueInput } from "./ApplicationWhereUniqueInput";

export type DeleteApplicationArgs = {
  where: ApplicationWhereUniqueInput;
};
