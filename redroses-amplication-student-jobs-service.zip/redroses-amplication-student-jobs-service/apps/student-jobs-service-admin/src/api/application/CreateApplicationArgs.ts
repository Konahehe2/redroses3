import { ApplicationCreateInput } from "./ApplicationCreateInput";

export type CreateApplicationArgs = {
  data: ApplicationCreateInput;
};
