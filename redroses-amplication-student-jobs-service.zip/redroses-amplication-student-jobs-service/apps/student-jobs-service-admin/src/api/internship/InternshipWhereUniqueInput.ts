export type InternshipWhereUniqueInput = {
  id: string;
};
