import { Employer } from "../employer/Employer";

export type Internship = {
  createdAt: Date;
  description: string | null;
  duration: string | null;
  employer?: Employer | null;
  id: string;
  location: string | null;
  stipend: number | null;
  title: string | null;
  updatedAt: Date;
};
