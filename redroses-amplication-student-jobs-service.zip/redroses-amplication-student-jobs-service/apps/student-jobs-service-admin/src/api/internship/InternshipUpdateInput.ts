import { EmployerWhereUniqueInput } from "../employer/EmployerWhereUniqueInput";

export type InternshipUpdateInput = {
  description?: string | null;
  duration?: string | null;
  employer?: EmployerWhereUniqueInput | null;
  location?: string | null;
  stipend?: number | null;
  title?: string | null;
};
