import { StringNullableFilter } from "../../util/StringNullableFilter";
import { EmployerWhereUniqueInput } from "../employer/EmployerWhereUniqueInput";
import { StringFilter } from "../../util/StringFilter";
import { FloatNullableFilter } from "../../util/FloatNullableFilter";

export type InternshipWhereInput = {
  description?: StringNullableFilter;
  duration?: StringNullableFilter;
  employer?: EmployerWhereUniqueInput;
  id?: StringFilter;
  location?: StringNullableFilter;
  stipend?: FloatNullableFilter;
  title?: StringNullableFilter;
};
