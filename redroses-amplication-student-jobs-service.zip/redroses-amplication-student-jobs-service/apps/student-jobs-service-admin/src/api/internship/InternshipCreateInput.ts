import { EmployerWhereUniqueInput } from "../employer/EmployerWhereUniqueInput";

export type InternshipCreateInput = {
  description?: string | null;
  duration?: string | null;
  employer?: EmployerWhereUniqueInput | null;
  location?: string | null;
  stipend?: number | null;
  title?: string | null;
};
