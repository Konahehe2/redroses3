import { InternshipWhereUniqueInput } from "./InternshipWhereUniqueInput";

export type InternshipFindUniqueArgs = {
  where: InternshipWhereUniqueInput;
};
