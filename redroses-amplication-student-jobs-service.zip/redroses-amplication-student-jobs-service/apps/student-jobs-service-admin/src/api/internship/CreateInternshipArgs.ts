import { InternshipCreateInput } from "./InternshipCreateInput";

export type CreateInternshipArgs = {
  data: InternshipCreateInput;
};
