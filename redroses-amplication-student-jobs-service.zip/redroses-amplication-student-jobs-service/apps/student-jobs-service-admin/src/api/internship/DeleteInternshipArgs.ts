import { InternshipWhereUniqueInput } from "./InternshipWhereUniqueInput";

export type DeleteInternshipArgs = {
  where: InternshipWhereUniqueInput;
};
