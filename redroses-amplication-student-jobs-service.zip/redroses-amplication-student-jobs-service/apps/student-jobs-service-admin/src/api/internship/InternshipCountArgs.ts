import { InternshipWhereInput } from "./InternshipWhereInput";

export type InternshipCountArgs = {
  where?: InternshipWhereInput;
};
