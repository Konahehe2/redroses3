import { ApplicationWhereUniqueInput } from "../application/ApplicationWhereUniqueInput";

export type ApplicationCreateNestedManyWithoutJobsInput = {
  connect?: Array<ApplicationWhereUniqueInput>;
};
