import { JobWhereUniqueInput } from "./JobWhereUniqueInput";

export type JobFindUniqueArgs = {
  where: JobWhereUniqueInput;
};
