import { JobCreateInput } from "./JobCreateInput";

export type CreateJobArgs = {
  data: JobCreateInput;
};
