import { JobWhereUniqueInput } from "./JobWhereUniqueInput";

export type DeleteJobArgs = {
  where: JobWhereUniqueInput;
};
