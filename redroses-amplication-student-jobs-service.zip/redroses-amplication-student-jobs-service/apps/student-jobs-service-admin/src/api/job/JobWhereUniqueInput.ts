export type JobWhereUniqueInput = {
  id: string;
};
