import { JobWhereInput } from "./JobWhereInput";

export type JobCountArgs = {
  where?: JobWhereInput;
};
