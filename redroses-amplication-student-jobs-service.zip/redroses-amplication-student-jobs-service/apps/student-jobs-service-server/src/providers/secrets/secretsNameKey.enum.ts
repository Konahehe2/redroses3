export enum EnumSecretsNameKey {
    SecretA = "/path/to:SecretA",
    SecretB = "/path/to:SecretB",
    Common = "/path/to/secrets/common",
    JwtSecretKey = "JWT_SECRET_KEY"
}